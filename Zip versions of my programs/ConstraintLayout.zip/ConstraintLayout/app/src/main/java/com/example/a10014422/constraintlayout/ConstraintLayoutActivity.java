package com.example.a10014422.constraintlayout;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ConstraintLayoutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_constraint_layout);
    }
}
