package com.example.swapn.conversionproject;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ConversionProjectActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conversion_project);
    }
}
